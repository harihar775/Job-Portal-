import { and, desc, eq, like, or, gte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, Job, InsertJob, jobs, users } from "../drizzle/schema";
import { seededJobs, type JobRecord } from "../shared/jobData";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;
let seedAttempted = false;

export type JobFilters = {
  q?: string;
  location?: string;
  workMode?: JobRecord["workMode"];
  jobType?: JobRecord["jobType"];
  experience?: string;
  category?: string;
  recency?: "24h" | "7d" | "30d" | "all";
};

export type NormalizedJob = Omit<JobRecord, "postedAt"> & {
  id: string;
  postedAt: string;
};

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

function toJobRecord(job: Job): NormalizedJob {
  return {
    id: job.externalId,
    externalId: job.externalId,
    title: job.title,
    company: job.company,
    location: job.location,
    country: job.country,
    workMode: job.workMode,
    jobType: job.jobType,
    experienceLevel: job.experienceLevel,
    category: job.category,
    postedAt: new Date(job.postedAt).toISOString(),
    summary: job.summary,
    description: job.description,
    qualifications: safeJsonArray(job.qualifications),
    skills: safeJsonArray(job.skills),
    source: job.source as JobRecord["source"],
    sourceUrl: job.sourceUrl,
    applyUrl: job.applyUrl,
    sourceNote: job.sourceNote,
    fresherFit: job.fresherFit,
  };
}

function safeJsonArray(value: string): string[] {
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter(item => typeof item === "string") : [];
  } catch {
    return value.split(",").map(item => item.trim()).filter(Boolean);
  }
}

function fallbackJob(job: JobRecord): NormalizedJob {
  return { ...job, id: job.externalId };
}

function matchesFilters(job: JobRecord, filters: JobFilters) {
  const search = filters.q?.trim().toLowerCase();
  const haystack = [job.title, job.company, job.location, job.category, job.skills.join(" ")].join(" ").toLowerCase();
  if (search && !haystack.includes(search)) return false;
  if (filters.location && !job.location.toLowerCase().includes(filters.location.toLowerCase())) return false;
  if (filters.workMode && job.workMode !== filters.workMode) return false;
  if (filters.jobType && job.jobType !== filters.jobType) return false;
  if (filters.experience && job.experienceLevel !== filters.experience) return false;
  if (filters.category && job.category !== filters.category) return false;
  if (filters.recency && filters.recency !== "all") {
    const days = filters.recency === "24h" ? 1 : filters.recency === "7d" ? 7 : 30;
    const threshold = Date.now() - days * 24 * 60 * 60 * 1000;
    if (new Date(job.postedAt).getTime() < threshold) return false;
  }
  return true;
}

export async function seedJobsInDatabase() {
  if (seedAttempted) return;
  seedAttempted = true;
  const db = await getDb();
  if (!db) return;

  try {
    const existing = await db.select({ id: jobs.id }).from(jobs).limit(1);
    if (existing.length > 0) return;
    const values: InsertJob[] = seededJobs.map(job => ({
      externalId: job.externalId,
      title: job.title,
      company: job.company,
      location: job.location,
      country: job.country,
      workMode: job.workMode,
      jobType: job.jobType,
      experienceLevel: job.experienceLevel,
      category: job.category,
      postedAt: new Date(job.postedAt),
      summary: job.summary,
      description: job.description,
      qualifications: JSON.stringify(job.qualifications),
      skills: JSON.stringify(job.skills),
      source: job.source,
      sourceUrl: job.sourceUrl,
      applyUrl: job.applyUrl,
      sourceNote: job.sourceNote,
      fresherFit: job.fresherFit,
    }));
    await db.insert(jobs).values(values);
    console.log(`[Database] Seeded ${values.length} public job records`);
  } catch (error) {
    seedAttempted = false;
    console.warn("[Database] Job seed skipped:", error);
  }
}

export async function listJobs(filters: JobFilters = {}): Promise<NormalizedJob[]> {
  const db = await getDb();
  if (!db) {
    return seededJobs.filter(job => matchesFilters(job, filters)).map(fallbackJob);
  }

  await seedJobsInDatabase();
  const conditions = [];
  if (filters.q?.trim()) {
    const term = `%${filters.q.trim()}%`;
    conditions.push(or(like(jobs.title, term), like(jobs.company, term), like(jobs.location, term), like(jobs.category, term), like(jobs.skills, term)));
  }
  if (filters.location) conditions.push(like(jobs.location, `%${filters.location}%`));
  if (filters.workMode) conditions.push(eq(jobs.workMode, filters.workMode));
  if (filters.jobType) conditions.push(eq(jobs.jobType, filters.jobType));
  if (filters.experience) conditions.push(eq(jobs.experienceLevel, filters.experience));
  if (filters.category) conditions.push(eq(jobs.category, filters.category));
  if (filters.recency && filters.recency !== "all") {
    const days = filters.recency === "24h" ? 1 : filters.recency === "7d" ? 7 : 30;
    conditions.push(gte(jobs.postedAt, new Date(Date.now() - days * 24 * 60 * 60 * 1000)));
  }
  const rows = await db.select().from(jobs).where(conditions.length ? and(...conditions) : undefined).orderBy(desc(jobs.postedAt)).limit(50);
  return rows.map(toJobRecord);
}

export async function getJobByExternalId(externalId: string): Promise<NormalizedJob | null> {
  const db = await getDb();
  if (!db) {
    const fallback = seededJobs.find(job => job.externalId === externalId);
    return fallback ? fallbackJob(fallback) : null;
  }
  await seedJobsInDatabase();
  const rows = await db.select().from(jobs).where(eq(jobs.externalId, externalId)).limit(1);
  return rows.length ? toJobRecord(rows[0]) : null;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}
