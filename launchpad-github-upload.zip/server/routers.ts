import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { getJobByExternalId, listJobs } from "./db";
import { sourceHighlights } from "../shared/jobData";

const jobFilters = z.object({
  q: z.string().optional(),
  location: z.string().optional(),
  workMode: z.enum(["Remote", "Hybrid", "On-site"]).optional(),
  jobType: z.enum(["Full-time", "Internship", "Contract"]).optional(),
  experience: z.string().optional(),
  category: z.string().optional(),
  recency: z.enum(["24h", "7d", "30d", "all"]).optional(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  jobs: router({
    list: publicProcedure.input(jobFilters).query(async ({ input }) => {
      const jobs = await listJobs(input);
      return {
        jobs,
        total: jobs.length,
        refreshedAt: new Date().toISOString(),
        snapshotLabel: "Public-source snapshot",
        sources: sourceHighlights,
      };
    }),
    detail: publicProcedure.input(z.object({ id: z.string().min(1) })).query(async ({ input }) => {
      return getJobByExternalId(input.id);
    }),
    sources: publicProcedure.query(() => sourceHighlights),
  }),
});

export type AppRouter = typeof appRouter;
