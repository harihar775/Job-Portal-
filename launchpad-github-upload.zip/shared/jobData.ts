export type JobRecord = {
  externalId: string;
  title: string;
  company: string;
  location: string;
  country: string;
  workMode: "Remote" | "Hybrid" | "On-site";
  jobType: "Full-time" | "Internship" | "Contract";
  experienceLevel: string;
  category: string;
  postedAt: string;
  summary: string;
  description: string;
  qualifications: string[];
  skills: string[];
  source: "LinkedIn" | "Indeed" | "Palantir Careers";
  sourceUrl: string;
  applyUrl: string;
  sourceNote: string;
  fresherFit: "Strong fit" | "Good fit" | "Stretch";
};

export const seededJobs: JobRecord[] = [
  {
    externalId: "linkedin-cin7-junior-swe-4487044689",
    title: "Junior Software Engineer",
    company: "Cin7",
    location: "Pune, Maharashtra",
    country: "India",
    workMode: "Hybrid",
    jobType: "Full-time",
    experienceLevel: "0–2 years",
    category: "Software engineering",
    postedAt: "2026-11-04T09:00:00.000Z",
    summary: "Build product features with a growing engineering team and get your first strong production wins.",
    description:
      "A practical first-step engineering role for candidates who want exposure to product development, code reviews, and shipping software with an experienced team.",
    qualifications: ["Computer science or equivalent background", "Comfort with one programming language", "Ability to learn quickly and communicate clearly"],
    skills: ["JavaScript", "APIs", "Git", "Problem solving"],
    source: "LinkedIn",
    sourceUrl: "https://in.linkedin.com/jobs/view/junior-software-engineer-at-cin7-4487044689",
    applyUrl: "https://in.linkedin.com/jobs/view/junior-software-engineer-at-cin7-4487044689",
    sourceNote: "Public LinkedIn India search result · 3 days ago",
    fresherFit: "Strong fit",
  },
  {
    externalId: "linkedin-zebra-swe1-4485868307",
    title: "Software Engineer, I",
    company: "Zebra Technologies",
    location: "Pune, Maharashtra",
    country: "India",
    workMode: "On-site",
    jobType: "Full-time",
    experienceLevel: "0–2 years",
    category: "Software engineering",
    postedAt: "2026-11-06T09:00:00.000Z",
    summary: "Join an actively hiring team building tools used across a global technology business.",
    description:
      "An early-career role for engineers who enjoy building reliable systems, collaborating with teammates, and growing through real delivery work.",
    qualifications: ["Engineering or computer science background", "Foundational data structures knowledge", "Willingness to work from Pune"],
    skills: ["Java", "C++", "Testing", "Data structures"],
    source: "LinkedIn",
    sourceUrl: "https://in.linkedin.com/jobs/view/software-engineer-i-at-zebra-technologies-4485868307",
    applyUrl: "https://in.linkedin.com/jobs/view/software-engineer-i-at-zebra-technologies-4485868307",
    sourceNote: "Public LinkedIn India search result · 1 day ago",
    fresherFit: "Good fit",
  },
  {
    externalId: "linkedin-vmax-full-stack-fresher-4463243315",
    title: "Full Stack Developer — Freshers",
    company: "VMax Wellness",
    location: "Coimbatore, Tamil Nadu",
    country: "India",
    workMode: "On-site",
    jobType: "Full-time",
    experienceLevel: "Fresher",
    category: "Full stack",
    postedAt: "2026-09-07T09:00:00.000Z",
    summary: "A clearly fresher-labelled full-stack opening for candidates ready to learn by shipping.",
    description:
      "Work across frontend and backend tasks in an onsite environment. This is a good fit for candidates with projects, coursework, or a portfolio but limited professional experience.",
    qualifications: ["Academic or project experience in web development", "Basic understanding of frontend and backend concepts", "Comfort collaborating onsite"],
    skills: ["React", "Node.js", "SQL", "REST APIs"],
    source: "LinkedIn",
    sourceUrl: "https://in.linkedin.com/jobs/view/full-stack-developer-freshers-onsite-at-vmax-wellness-4463243315",
    applyUrl: "https://in.linkedin.com/jobs/view/full-stack-developer-freshers-onsite-at-vmax-wellness-4463243315",
    sourceNote: "Public LinkedIn India search result · 2 months ago",
    fresherFit: "Strong fit",
  },
  {
    externalId: "linkedin-trainingbasket-junior-python-4478433237",
    title: "Junior Python Developer",
    company: "Training Basket",
    location: "Noida, Uttar Pradesh",
    country: "India",
    workMode: "Hybrid",
    jobType: "Full-time",
    experienceLevel: "0–1 years",
    category: "Data & AI",
    postedAt: "2026-10-17T09:00:00.000Z",
    summary: "A junior Python path for candidates who want to turn scripting and projects into a first role.",
    description:
      "Support application development and automation work while building confidence with Python, debugging, and team delivery practices.",
    qualifications: ["Python fundamentals", "Small projects or coursework to discuss", "Curiosity and structured problem solving"],
    skills: ["Python", "SQL", "Debugging", "Automation"],
    source: "LinkedIn",
    sourceUrl: "https://in.linkedin.com/jobs/view/junior-python-developer-at-training-basket-4478433237",
    applyUrl: "https://in.linkedin.com/jobs/view/junior-python-developer-at-training-basket-4478433237",
    sourceNote: "Public LinkedIn India search result · 3 weeks ago",
    fresherFit: "Strong fit",
  },
  {
    externalId: "linkedin-stripe-new-grad-4484442637",
    title: "Software Engineer, New Grad",
    company: "Stripe",
    location: "Bengaluru, Karnataka",
    country: "India",
    workMode: "Hybrid",
    jobType: "Full-time",
    experienceLevel: "New grad",
    category: "Software engineering",
    postedAt: "2026-10-31T09:00:00.000Z",
    summary: "A high-signal new-grad opportunity for candidates who want to work on infrastructure and product systems.",
    description:
      "Join a product engineering environment where new graduates can learn from experienced teams and contribute to software that supports businesses around the world.",
    qualifications: ["Graduating student or recent graduate", "Strong programming fundamentals", "Interest in building reliable products"],
    skills: ["Java", "Ruby", "Go", "Distributed systems"],
    source: "LinkedIn",
    sourceUrl: "https://in.linkedin.com/jobs/view/software-engineer-new-grad-at-stripe-4484442637",
    applyUrl: "https://in.linkedin.com/jobs/view/software-engineer-new-grad-at-stripe-4484442637",
    sourceNote: "Public LinkedIn India search result · 1 week ago",
    fresherFit: "Good fit",
  },
  {
    externalId: "indeed-soranova-software-fresher-d58f533f017a275e",
    title: "Software Developer — Fresher",
    company: "Soranova Technologies",
    location: "Remote · India",
    country: "India",
    workMode: "Remote",
    jobType: "Full-time",
    experienceLevel: "Fresher",
    category: "Software engineering",
    postedAt: "2026-11-02T09:00:00.000Z",
    summary: "Remote entry-level opening with room to learn software development, testing, and debugging.",
    description:
      "Support the design and development of software applications while learning professional testing, debugging, and delivery workflows in a remote setup.",
    qualifications: ["Familiarity with software development fundamentals", "Willingness to learn testing and debugging", "Reliable written communication"],
    skills: ["Software development", "Testing", "Debugging", "Git"],
    source: "Indeed",
    sourceUrl: "https://in.indeed.com/q-entry-level-software-engineer-jobs.html",
    applyUrl: "https://in.indeed.com/rc/clk?jk=d58f533f017a275e",
    sourceNote: "Public Indeed India search result · fresher-labelled",
    fresherFit: "Strong fit",
  },
  {
    externalId: "indeed-exact-trainee-75a0275d567ddb76",
    title: "Software Engineer — Trainee",
    company: "Exact IT Solutions",
    location: "Delhi, Delhi",
    country: "India",
    workMode: "On-site",
    jobType: "Full-time",
    experienceLevel: "Trainee",
    category: "Web development",
    postedAt: "2026-10-27T09:00:00.000Z",
    summary: "A classic trainee role that makes the expected web stack clear before you apply.",
    description:
      "Learn through hands-on work across web technologies and database-backed applications. A fit for candidates with coursework, bootcamp work, or personal projects.",
    qualifications: ["Tech, MCA, or equivalent computer science background", "Basic HTML, CSS, and JavaScript", "Interest in PHP and MySQL"],
    skills: ["HTML", "CSS", "JavaScript", "PHP", "MySQL"],
    source: "Indeed",
    sourceUrl: "https://in.indeed.com/q-entry-level-software-engineer-jobs.html",
    applyUrl: "https://in.indeed.com/rc/clk?jk=75a0275d567ddb76",
    sourceNote: "Public Indeed India search result · trainee-labelled",
    fresherFit: "Strong fit",
  },
  {
    externalId: "indeed-sadhana-entry-level-7a577c18954a7b09",
    title: "Software Engineer (Entry-level / Fresher)",
    company: "Sadhana IT Solutions",
    location: "Pune, Maharashtra",
    country: "India",
    workMode: "On-site",
    jobType: "Full-time",
    experienceLevel: "Entry-level",
    category: "Software engineering",
    postedAt: "2026-10-29T09:00:00.000Z",
    summary: "A broad entry-level engineering role spanning web, mobile, cloud, and data learning paths.",
    description:
      "A generalist starting point for candidates who learn quickly and want to explore modern software delivery across product and platform areas.",
    qualifications: ["Entry-level or fresher profile", "Strong learning mindset", "Ability to work from Pune"],
    skills: ["Web apps", "Cloud", "DevOps", "Data science"],
    source: "Indeed",
    sourceUrl: "https://in.indeed.com/q-entry-level-software-engineer-jobs.html",
    applyUrl: "https://in.indeed.com/rc/clk?jk=7a577c18954a7b09",
    sourceNote: "Public Indeed India search result · entry-level-labelled",
    fresherFit: "Good fit",
  },
  {
    externalId: "lever-palantir-new-grad-94984771",
    title: "Software Engineer, New Grad",
    company: "Palantir Technologies",
    location: "New York, NY",
    country: "United States",
    workMode: "Hybrid",
    jobType: "Full-time",
    experienceLevel: "New grad",
    category: "Software engineering",
    postedAt: "2026-10-25T09:00:00.000Z",
    summary: "A high-growth new-grad role with mentorship, product ownership, and direct exposure to production systems.",
    description:
      "Palantir’s public role page describes new-grad engineers contributing across the product lifecycle, collaborating with technical and non-technical partners, and learning through mentorship.",
    qualifications: ["Engineering background in CS, mathematics, software engineering, or physics", "Familiarity with data structures and cloud infrastructure", "Coding experience in Java, C++, Python, JavaScript, or similar"],
    skills: ["Java", "Go", "TypeScript", "React", "Data structures"],
    source: "Palantir Careers",
    sourceUrl: "https://jobs.lever.co/palantir/94984771-0704-446c-88c6-91ce748f6d92",
    applyUrl: "https://jobs.lever.co/palantir/94984771-0704-446c-88c6-91ce748f6d92/apply",
    sourceNote: "Public Palantir Careers / Lever detail page",
    fresherFit: "Stretch",
  },
];

export const sourceHighlights = [
  { name: "LinkedIn", label: "7,000+ entry-level software roles visible in India", href: "https://in.linkedin.com/jobs/entry-level-software-engineer-jobs", tone: "blue" },
  { name: "Indeed", label: "Fresher and trainee listings across India", href: "https://in.indeed.com/q-entry-level-software-engineer-jobs.html", tone: "teal" },
  { name: "Google Careers", label: "Early-career, internship, and apprenticeship paths", href: "https://www.google.com/about/careers/applications/early-career", tone: "yellow" },
];
