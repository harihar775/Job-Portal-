import { useMemo, useState } from "react";
import { ArrowRight, ChevronDown, CircleHelp, Filter, Layers3, Search, ShieldCheck, Sparkles, X } from "lucide-react";
import { Link } from "wouter";
import JobCard from "@/components/JobCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { sourceHighlights } from "../../../shared/jobData";

type FilterState = {
  q: string;
  location: string;
  workMode?: "Remote" | "Hybrid" | "On-site";
  jobType?: "Full-time" | "Internship" | "Contract";
  experience?: string;
  category?: string;
  recency: "24h" | "7d" | "30d" | "all";
};

const initialFilters: FilterState = { q: "", location: "", workMode: undefined, jobType: undefined, experience: undefined, category: undefined, recency: "all" };

const filterOptions = {
  workMode: ["Remote", "Hybrid", "On-site"],
  jobType: ["Full-time", "Internship", "Contract"],
  experience: ["Fresher", "0–1 years", "0–2 years", "Entry-level", "Trainee", "New grad"],
  category: ["Software engineering", "Full stack", "Data & AI", "Web development"],
  recency: ["24h", "7d", "30d", "all"],
} as const;

function SelectFilter({ value, onChange, options, label }: { value?: string; onChange: (value: string | undefined) => void; options: readonly string[]; label: string }) {
  return (
    <label className="filter-field">
      <span>{label}</span>
      <span className="relative block">
        <select value={value ?? ""} onChange={event => onChange(event.target.value || undefined)}>
          <option value="">All {label.toLowerCase()}</option>
          {options.map(option => <option key={option} value={option}>{option}</option>)}
        </select>
        <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[var(--ink-muted)]" size={15} />
      </span>
    </label>
  );
}

export default function Home() {
  const [filters, setFilters] = useState<FilterState>(initialFilters);
  const [savedJobs, setSavedJobs] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem("launchpad-saved") ?? "[]"); } catch { return []; }
  });
  const query = trpc.jobs.list.useQuery(filters, { staleTime: 60_000, retry: 1 });
  const jobs = query.data?.jobs ?? [];
  const activeFilterCount = useMemo(() => Object.entries(filters).filter(([key, value]) => key !== "q" && value && value !== "all").length, [filters]);

  function updateFilter<K extends keyof FilterState>(key: K, value: FilterState[K]) {
    setFilters(current => ({ ...current, [key]: value }));
  }

  function toggleSaved(id: string) {
    setSavedJobs(current => {
      const next = current.includes(id) ? current.filter(item => item !== id) : [...current, id];
      localStorage.setItem("launchpad-saved", JSON.stringify(next));
      return next;
    });
  }

  function clearFilters() {
    setFilters(initialFilters);
  }

  return (
    <div className="min-h-screen bg-[var(--canvas)]">
      <header className="site-header">
        <div className="container flex h-[72px] items-center justify-between gap-6">
          <Link href="/" className="brand-mark no-underline"><span className="brand-icon">↗</span><span>launchpad</span></Link>
          <nav className="hidden items-center gap-7 text-[13px] font-medium text-[var(--ink-soft)] md:flex">
            <a href="#discover" className="nav-link active">Discover roles</a>
            <a href="#sources" className="nav-link">How sources work</a>
            <a href="#freshers" className="nav-link">For freshers</a>
          </nav>
          <div className="flex items-center gap-2">
            <span className="hidden rounded-full border border-[var(--line)] bg-white/60 px-3 py-1.5 text-[11px] font-semibold uppercase tracking-[0.12em] text-[var(--ink-muted)] sm:inline-flex">Public source snapshot</span>
            <Button variant="outline" size="sm" className="rounded-full border-[var(--line-strong)] bg-white/70">Sign in</Button>
          </div>
        </div>
      </header>

      <main>
        <section className="hero-section">
          <div className="container relative grid gap-12 py-16 lg:grid-cols-[0.8fr_1.2fr] lg:py-24">
            <div className="hero-copy">
              <div className="eyebrow"><span className="eyebrow-dot" /> A calmer first step into the job market</div>
              <h1>Start with roles that <span>make sense.</span></h1>
              <p className="hero-lede">A focused board for early-career candidates. Find entry-level work, understand the fit, and apply on the original listing.</p>
              <div className="hero-proof-row">
                <div><strong>9</strong><span>curated roles</span></div>
                <div><strong>3</strong><span>public sources</span></div>
                <div><strong>0</strong><span>black-box applications</span></div>
              </div>
            </div>
            <div className="hero-search-wrap">
              <div className="hero-search-card">
                <div className="hero-search-label"><Sparkles size={15} /> What do you want to build?</div>
                <div className="hero-search-input">
                  <Search size={20} className="text-[var(--ink-muted)]" />
                  <Input value={filters.q} onChange={event => updateFilter("q", event.target.value)} placeholder="Try “Python”, “frontend”, or “remote”" />
                  {filters.q && <button type="button" onClick={() => updateFilter("q", "")} className="text-[var(--ink-muted)]"><X size={17} /></button>}
                </div>
                <div className="hero-search-hints"><span>Popular:</span><button type="button" onClick={() => updateFilter("q", "Python")}>Python</button><button type="button" onClick={() => updateFilter("q", "React")}>React</button><button type="button" onClick={() => updateFilter("q", "remote")}>Remote</button></div>
              </div>
              <div className="hero-note"><ShieldCheck size={16} /><span>Every role shows where it came from. You’ll always know where you’re applying.</span></div>
            </div>
          </div>
        </section>

        <section id="sources" className="source-strip-section">
          <div className="container">
            <div className="section-kicker"><span>01</span><span>Public, traceable, useful</span></div>
            <div className="source-strip">
              {sourceHighlights.map(source => <a key={source.name} href={source.href} target="_blank" rel="noreferrer" className={`source-highlight source-tone-${source.tone}`}><span className="source-highlight-mark">{source.name.slice(0, 2).toLowerCase()}</span><span><strong>{source.name}</strong><small>{source.label}</small></span><ArrowRight size={16} /></a>)}
            </div>
          </div>
        </section>

        <section id="discover" className="container discovery-section">
          <div className="section-intro-row">
            <div><div className="section-kicker"><span>02</span><span>The fresher board</span></div><h2>Roles worth your next hour.</h2><p>Curated from public job pages and organized around the details that matter early in your career.</p></div>
            <div className="hidden items-center gap-2 text-right text-[12px] text-[var(--ink-muted)] sm:flex"><Layers3 size={16} /><span>Refreshed<br /><strong className="text-[var(--ink)]">just now</strong></span></div>
          </div>

          <div className="filter-panel">
            <div className="filter-panel-top"><div className="flex items-center gap-2 text-sm font-semibold text-[var(--ink)]"><Filter size={16} className="text-[var(--violet)]" /> Tune your search</div><button type="button" onClick={clearFilters} className="text-xs font-semibold text-[var(--violet)] hover:underline">Reset filters</button></div>
            <div className="filter-grid">
              <label className="filter-field filter-search"><span>Location</span><span className="relative block"><Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[var(--ink-muted)]" size={15} /><input value={filters.location} onChange={event => updateFilter("location", event.target.value)} placeholder="City or remote" /></span></label>
              <SelectFilter label="Work mode" value={filters.workMode} options={filterOptions.workMode} onChange={value => updateFilter("workMode", value as FilterState["workMode"])} />
              <SelectFilter label="Job type" value={filters.jobType} options={filterOptions.jobType} onChange={value => updateFilter("jobType", value as FilterState["jobType"])} />
              <SelectFilter label="Experience" value={filters.experience} options={filterOptions.experience} onChange={value => updateFilter("experience", value)} />
              <SelectFilter label="Role type" value={filters.category} options={filterOptions.category} onChange={value => updateFilter("category", value)} />
              <SelectFilter label="Freshness" value={filters.recency} options={filterOptions.recency} onChange={value => updateFilter("recency", (value ?? "all") as FilterState["recency"])} />
            </div>
            {activeFilterCount > 0 && <div className="active-filters"><span>Active:</span>{Object.entries(filters).filter(([key, value]) => key !== "q" && value && value !== "all").map(([key, value]) => <Badge key={key} variant="outline" className="gap-1 rounded-full border-[var(--violet-soft)] bg-[var(--violet-wash)] text-[var(--violet)]">{value}<button type="button" onClick={() => updateFilter(key as keyof FilterState, key === "recency" ? "all" as FilterState["recency"] : undefined as never)}><X size={12} /></button></Badge>)}</div>}
          </div>

          <div className="results-header"><span>{query.isFetching ? "Refreshing roles…" : `${query.data?.total ?? 0} roles found`}</span><span className="results-header-note"><CircleHelp size={14} /> Snapshot data is linked to the original source</span></div>
          {query.isLoading ? <div className="job-list">{Array.from({ length: 4 }).map((_, index) => <div key={index} className="job-skeleton" />)}</div> : query.isError ? <div className="state-card"><div className="state-icon">!</div><h3>We couldn’t refresh the board.</h3><p>The public snapshot is still available in the app. Try again when you’re ready.</p><Button onClick={() => query.refetch()} className="rounded-full bg-[var(--violet)]">Try again</Button></div> : jobs.length === 0 ? <div className="state-card"><div className="state-icon"><Search size={20} /></div><h3>Nothing fits those filters yet.</h3><p>Try widening the location or clearing a filter. Fresher-friendly roles move quickly.</p><Button variant="outline" onClick={clearFilters} className="rounded-full">Clear filters</Button></div> : <div className="job-list">{jobs.map(job => <JobCard key={job.id} job={job} saved={savedJobs.includes(job.id)} onSave={toggleSaved} />)}</div>}
        </section>

        <section id="freshers" className="container closing-section">
          <div className="closing-card"><div><div className="section-kicker light"><span>03</span><span>Before you apply</span></div><h2>Make your first move a confident one.</h2><p>Read the requirements, tailor your story, then take the final step on the source page. Launchpad never hides the handoff.</p></div><div className="closing-list"><div><span>01</span><p><strong>Check the fit signal.</strong><br />It’s a quick read on how clearly the role welcomes early-career candidates.</p></div><div><span>02</span><p><strong>Open the source.</strong><br />Your application belongs with the employer or job board that posted it.</p></div></div></div>
        </section>
      </main>

      <footer className="site-footer"><div className="container flex flex-col justify-between gap-5 py-8 sm:flex-row sm:items-center"><div className="brand-mark small"><span className="brand-icon">↗</span><span>launchpad</span></div><p>Built for the first 0–2 years. Sourced in public. Applied elsewhere.</p><div className="flex items-center gap-4 text-xs text-[var(--ink-muted)]"><Link href="/" className="hover:text-[var(--violet)]">Home</Link><a href="https://www.google.com/about/careers/applications/early-career" target="_blank" rel="noreferrer" className="hover:text-[var(--violet)]">Google Careers</a></div></div></footer>
    </div>
  );
}
