import { useEffect, useState } from "react";
import { ArrowLeft, ArrowUpRight, Bookmark, Check, Clipboard, Clock3, ExternalLink, MapPin, ShieldCheck, Sparkles } from "lucide-react";
import { Link, useLocation, useParams } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import NotFound from "@/pages/NotFound";

function formatDate(date: string) {
  return new Intl.DateTimeFormat("en", { month: "short", day: "numeric", year: "numeric" }).format(new Date(date));
}

function fitCopy(fit: string) {
  if (fit === "Strong fit") return "This role explicitly welcomes an early-career profile or keeps the experience bar close to 0–2 years.";
  if (fit === "Good fit") return "A realistic option if your projects, coursework, or internships match the core skills in the description.";
  return "A stretch role: keep it bookmarked if the mission is compelling, but compare the requirements carefully before applying.";
}

export default function JobDetail() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const query = trpc.jobs.detail.useQuery({ id: id ?? "" }, { enabled: Boolean(id), retry: 1 });
  const [saved, setSaved] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!query.data) return;
    document.title = `${query.data.title} · Launchpad`;
    try { setSaved(JSON.parse(localStorage.getItem("launchpad-saved") ?? "[]").includes(query.data.id)); } catch { /* no-op */ }
    return () => { document.title = "Launchpad — Fresher Jobs"; };
  }, [query.data]);

  if (query.isLoading) return <div className="min-h-screen bg-[var(--canvas)]"><div className="container py-24"><div className="detail-skeleton" /></div></div>;
  if (query.isError || !query.data) return <NotFound />;
  const job = query.data;

  function toggleSaved() {
    try {
      const current: string[] = JSON.parse(localStorage.getItem("launchpad-saved") ?? "[]");
      const next = current.includes(job.id) ? current.filter(item => item !== job.id) : [...current, job.id];
      localStorage.setItem("launchpad-saved", JSON.stringify(next));
      setSaved(!current.includes(job.id));
    } catch { setSaved(current => !current); }
  }

  async function copyLink() {
    try { await navigator.clipboard.writeText(window.location.href); setCopied(true); setTimeout(() => setCopied(false), 1600); } catch { /* clipboard may be unavailable */ }
  }

  return (
    <div className="min-h-screen bg-[var(--canvas)]">
      <header className="site-header"><div className="container flex h-[72px] items-center justify-between gap-4"><Link href="/" className="brand-mark no-underline"><span className="brand-icon">↗</span><span>launchpad</span></Link><div className="flex items-center gap-2"><Button variant="ghost" size="sm" onClick={() => setLocation("/")} className="rounded-full text-[var(--ink-soft)]"><ArrowLeft size={15} /> Back to roles</Button><Button variant="outline" size="sm" onClick={toggleSaved} className="rounded-full border-[var(--line-strong)] bg-white/70"><Bookmark size={15} fill={saved ? "currentColor" : "none"} /> {saved ? "Saved" : "Save"}</Button></div></div></header>
      <main className="container detail-page">
        <div className="detail-breadcrumb"><Link href="/">Discover roles</Link><span>/</span><span>{job.company}</span></div>
        <section className="detail-hero"><div className="detail-hero-main"><div className="flex flex-wrap items-center gap-2"><span className={`source-mark source-${job.source.toLowerCase().replaceAll(" ", "-")}`}>{job.source.slice(0, 2).toLowerCase()}</span><span className="text-xs font-bold uppercase tracking-[0.14em] text-[var(--ink-muted)]">{job.source}</span><span className="mx-1 text-[var(--line-strong)]">·</span><span className="text-xs text-[var(--ink-muted)]">{job.sourceNote}</span></div><h1>{job.title}</h1><p className="detail-company">{job.company}</p><div className="detail-meta"><span><MapPin size={16} />{job.location}</span><span><BriefcaseIcon />{job.workMode}</span><span><Clock3 size={16} />{job.jobType}</span><span>Posted {formatDate(job.postedAt)}</span></div></div><div className={`detail-fit ${job.fresherFit === "Strong fit" ? "fit-strong" : job.fresherFit === "Good fit" ? "fit-good" : "fit-stretch"}`}><Sparkles size={17} /><span className="text-[11px] font-bold uppercase tracking-[0.16em]">Launchpad fit signal</span><strong>{job.fresherFit}</strong><p>{fitCopy(job.fresherFit)}</p></div></section>

        <div className="detail-layout"><article className="detail-content"><section><div className="section-kicker"><span>01</span><span>Why it’s interesting</span></div><p className="detail-lede">{job.summary}</p><p>{job.description}</p></section><section><div className="section-kicker"><span>02</span><span>What you’ll bring</span></div><div className="detail-columns"><div><h3>Qualifications</h3><ul>{job.qualifications.map(item => <li key={item}><Check size={15} />{item}</li>)}</ul></div><div><h3>Skills in the listing</h3><div className="skill-cloud">{job.skills.map(skill => <Badge key={skill} variant="outline" className="rounded-full border-[var(--line-strong)] bg-white/70 px-3 py-1.5 text-[12px] text-[var(--ink-soft)]">{skill}</Badge>)}</div></div></div></section><section className="source-provenance"><div className="flex items-start gap-3"><ShieldCheck className="mt-0.5 text-[var(--mint-deep)]" size={19} /><div><h3>Source provenance</h3><p>{job.sourceNote}. We link back to the original public listing so you can verify the details before applying.</p><a href={job.sourceUrl} target="_blank" rel="noreferrer">View original source <ArrowUpRight size={14} /></a></div></div></section></article><aside className="detail-sidebar"><div className="apply-card"><div className="eyebrow"><span className="eyebrow-dot" /> Your next step</div><h2>Apply where the role lives.</h2><p>Launchpad is the calm before the click. Your application will open on {job.source}, not inside this portal.</p><a href={job.applyUrl} target="_blank" rel="noreferrer" className="apply-button">Open application <ExternalLink size={16} /></a><div className="apply-card-actions"><button type="button" onClick={copyLink}><Clipboard size={14} /> {copied ? "Copied" : "Copy link"}</button><button type="button" onClick={toggleSaved}><Bookmark size={14} fill={saved ? "currentColor" : "none"} /> {saved ? "Saved" : "Save role"}</button></div></div><div className="sidebar-note"><strong>Freshers’ checklist</strong><p>Have a one-page resume, one project you can explain end to end, and a short answer for why this company.</p></div></aside></div>
      </main>
      <footer className="site-footer"><div className="container flex items-center justify-between py-8"><div className="brand-mark small"><span className="brand-icon">↗</span><span>launchpad</span></div><p>Public source snapshot · external application handoff</p><Link href="/" className="text-xs font-semibold text-[var(--violet)]">Browse more roles</Link></div></footer>
    </div>
  );
}

function BriefcaseIcon() { return <span className="inline-block h-4 w-4 text-center text-[13px]">▣</span>; }
