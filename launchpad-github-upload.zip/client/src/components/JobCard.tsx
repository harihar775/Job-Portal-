import { ArrowUpRight, Bookmark, BriefcaseBusiness, Clock3, MapPin, Sparkles } from "lucide-react";
import { Link } from "wouter";
import type { NormalizedJob } from "../../../server/db";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const sourceInitials: Record<string, string> = {
  LinkedIn: "in",
  Indeed: "id",
  "Palantir Careers": "pa",
};

function formatPostedAt(date: string) {
  const posted = new Date(date).getTime();
  const days = Math.max(0, Math.floor((Date.now() - posted) / 86_400_000));
  if (days === 0) return "Posted today";
  if (days === 1) return "Posted yesterday";
  return `Posted ${days} days ago`;
}

export default function JobCard({ job, onSave, saved }: { job: NormalizedJob; onSave?: (jobId: string) => void; saved?: boolean }) {
  const fitTone = job.fresherFit === "Strong fit" ? "fit-strong" : job.fresherFit === "Good fit" ? "fit-good" : "fit-stretch";
  return (
    <article className="job-card group">
      <div className={`fit-rail ${fitTone}`}>
        <Sparkles size={14} strokeWidth={2.2} />
        <span>{job.fresherFit}</span>
      </div>
      <div className="job-card-body">
        <div className="flex items-start justify-between gap-4">
          <Link href={`/jobs/${job.id}`} className="min-w-0 flex-1 no-underline">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-[var(--ink-muted)]">
              <span className={`source-mark source-${job.source.toLowerCase().replaceAll(" ", "-")}`}>{sourceInitials[job.source] ?? "jo"}</span>
              {job.source}
            </div>
            <h3 className="mt-3 text-[1.2rem] font-semibold leading-tight tracking-[-0.03em] text-[var(--ink)] transition-colors group-hover:text-[var(--violet)]">{job.title}</h3>
            <p className="mt-1 font-medium text-[var(--ink-soft)]">{job.company}</p>
          </Link>
          <Button type="button" size="icon-sm" variant="ghost" aria-label={saved ? "Remove saved job" : "Save job"} className={saved ? "text-[var(--violet)]" : "text-[var(--ink-muted)]"} onClick={() => onSave?.(job.id)}>
            <Bookmark size={17} fill={saved ? "currentColor" : "none"} />
          </Button>
        </div>
        <div className="mt-5 flex flex-wrap gap-x-4 gap-y-2 text-[13px] text-[var(--ink-muted)]">
          <span className="inline-flex items-center gap-1.5"><MapPin size={14} /> {job.location}</span>
          <span className="inline-flex items-center gap-1.5"><BriefcaseBusiness size={14} /> {job.workMode}</span>
          <span className="inline-flex items-center gap-1.5"><Clock3 size={14} /> {formatPostedAt(job.postedAt)}</span>
        </div>
        <p className="mt-4 line-clamp-2 text-[14px] leading-6 text-[var(--ink-soft)]">{job.summary}</p>
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-[var(--line)] pt-4">
          <div className="flex flex-wrap gap-2">
            {job.skills.slice(0, 3).map(skill => <Badge key={skill} variant="outline" className="rounded-full border-[var(--line-strong)] px-2.5 py-1 text-[11px] font-medium text-[var(--ink-soft)]">{skill}</Badge>)}
          </div>
          <a href={job.applyUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-[13px] font-semibold text-[var(--violet)] no-underline hover:underline">
            Apply on {job.source} <ArrowUpRight size={14} />
          </a>
        </div>
      </div>
    </article>
  );
}
