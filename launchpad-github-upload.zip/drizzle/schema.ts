import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const jobs = mysqlTable("jobs", {
  id: int("id").autoincrement().primaryKey(),
  externalId: varchar("externalId", { length: 160 }).notNull().unique(),
  title: varchar("title", { length: 180 }).notNull(),
  company: varchar("company", { length: 140 }).notNull(),
  location: varchar("location", { length: 180 }).notNull(),
  country: varchar("country", { length: 80 }).notNull(),
  workMode: mysqlEnum("workMode", ["Remote", "Hybrid", "On-site"]).notNull(),
  jobType: mysqlEnum("jobType", ["Full-time", "Internship", "Contract"]).notNull(),
  experienceLevel: varchar("experienceLevel", { length: 80 }).notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  postedAt: timestamp("postedAt").notNull(),
  summary: text("summary").notNull(),
  description: text("description").notNull(),
  qualifications: text("qualifications").notNull(),
  skills: text("skills").notNull(),
  source: varchar("source", { length: 80 }).notNull(),
  sourceUrl: text("sourceUrl").notNull(),
  applyUrl: text("applyUrl").notNull(),
  sourceNote: text("sourceNote").notNull(),
  fresherFit: mysqlEnum("fresherFit", ["Strong fit", "Good fit", "Stretch"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Job = typeof jobs.$inferSelect;
export type InsertJob = typeof jobs.$inferInsert;
