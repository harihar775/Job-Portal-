# Launchpad — TODO

## 1. Full-stack job index and source-aware API — COMPLETE

- Create a normalized jobs table connected to the existing managed database.
- Store public listing fields including title, employer, location, work arrangement, job type, experience level, category, posting date, summary, qualifications, skills, source label, source URL, apply URL, and deduplication key.
- Seed the index with public-source fresher and entry-level listings, including LinkedIn, Indeed, employer ATS, and Google Careers source metadata.
- Add typed backend procedures for list/search/filter, detail lookup, and source/freshness metadata.
- Preserve a useful fallback dataset when a local preview has no database connection.

## 2. Fresher-focused discovery experience — COMPLETE

- Build a polished responsive landing and job discovery experience with clear navigation and professional presentation.
- Provide keyword search and practical filters for location, remote/on-site status, job type, experience level, role category, and recency.
- Show job cards with title, employer, location, work arrangement, experience expectations, posting date, source, and fresher suitability signals.
- Include loading, empty, error, unavailable-listing, duplicate/freshness messaging, and result-count states.

## 3. Job detail and honest application handoff — COMPLETE

- Add a detailed `/jobs/:id` view with role summary, qualifications, skills, source provenance, fit signals, and a prominent external apply action.
- Explain where the candidate will apply and open the original public listing or employer page in a new tab.
- Do not present an external application as completed inside Launchpad.

## 4. Visual polish and project readiness — COMPLETE

- Apply the approved editorial utility / Swiss-grid design direction with the Launchpad violet signature color, typography hierarchy, source chips, and fit-signal rails.
- Add the required static route manifest for `/`, `/jobs/:id`, and `/404`.
- Configure project logo metadata, verify TypeScript diagnostics, run typecheck/build, start the dev server, and verify health plus route-manifest responses.
- Save the finished project to the canonical repository checkpoint; publication remains separate unless explicitly requested.
