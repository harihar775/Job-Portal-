# Public source notes

Captured from public pages on 2026-11-07 for the Launchpad seed snapshot.

- Google Careers early-career hub: https://www.google.com/about/careers/applications/early-career
  - Publicly identifies early-career, internships, apprenticeships, and job search entry points.
- LinkedIn India entry-level software engineer search: https://in.linkedin.com/jobs/entry-level-software-engineer-jobs
  - Public page showed 7,000+ results and visible cards including Cin7, Zebra Technologies, VMax Wellness, Training Basket, Stripe, Honeywell, and other entry-level listings.
- Indeed India entry-level software engineer search: https://in.indeed.com/q-entry-level-software-engineer-jobs.html
  - Public page showed entry-level/fresher cards including Soranova Technologies, Exact IT Solutions, Sadhana IT Solutions, Giant Eagle, Ethnus, Sieger Spintech, and others.
- Palantir Lever new-grad listing: https://jobs.lever.co/palantir/94984771-0704-446c-88c6-91ce748f6d92
  - Public detail page described Software Engineer, New Grad, New York, full-time, hybrid, with mentorship, software development responsibilities, and common programming-language expectations.

The app labels records as a public source snapshot and links candidates to the original source. It does not claim continuous scraping, private LinkedIn access, or that an application was submitted inside Launchpad.
