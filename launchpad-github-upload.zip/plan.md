# Launchpad — Fresher Jobs

## Product intent

Launchpad is a fresher-first job discovery portal. It helps entry-level candidates find a small, understandable set of public job listings, compare fit signals quickly, and move to the original employer or job-board application page without implying that Launchpad submitted an application.

## Implementation approach

- Use the existing React + Vite frontend and Express + tRPC + Drizzle backend.
- Add a normalized `jobs` table with source attribution, deduplication key, work mode, job type, experience level, posting date, skills, qualification summary, and external apply URL.
- Seed the managed database with a curated public-source snapshot from LinkedIn, Indeed, Palantir Lever, and Google Careers. The UI will show the source and a “snapshot” freshness note rather than pretending the portal is continuously scraping private or inaccessible services.
- Expose public tRPC procedures for listing jobs, filtering/searching, fetching a single job, and returning source/freshness metadata. Keep a static in-memory fallback so the UI remains useful if a local preview has no database connection.
- Add a home/discovery route and `/jobs/:id` detail route. The apply CTA opens the original source in a new tab and a small in-app handoff panel explains the next step.
- Keep visual styling self-contained in Tailwind utilities and `index.css`; no decorative stock images are needed for this utility product.

## Project structure

- `client/src/pages/Home.tsx`: discovery experience, search, filters, curated source strip, job cards, empty/error states.
- `client/src/pages/JobDetail.tsx`: role detail, fit signals, skills, source provenance, application handoff.
- `client/src/components/JobCard.tsx`: reusable normalized listing card.
- `shared/jobData.ts`: public-source seed snapshot and shared job shape.
- `drizzle/schema.ts`: users plus normalized jobs table.
- `server/db.ts`: job seed, list, detail, and fallback query helpers.
- `server/routers.ts`: typed public job API procedures.
- `public/manus-routes.json`: route manifest for `/`, `/jobs/:id`, and `/404`.

## Design direction

### Shortlist of styles

- **Editorial utility / Swiss grid** — 0.06: crisp typographic hierarchy, strong alignment, and source-forward information design.
- **Soft SaaS dashboard** — 0.04: rounded cards, cool neutrals, and familiar product patterns.
- **Neo-brutalist launch board** — 0.07: high-contrast blocks, hard borders, and deliberately loud action states.

### Chosen style: Editorial utility / Swiss grid

- **Design Movement:** editorial utility with Swiss-grid discipline and a warm paper-like canvas.
- **Core Principles:** clarity before decoration; source provenance always visible; dense information with breathing room; confident, low-friction actions.
- **Color Philosophy:** deep ink and warm cream make the experience feel trustworthy and human; a single electric violet is the ownable signal for “fresh opportunity”; muted mint marks verified/fresher-fit states.
- **Layout Paradigm:** a left-aligned editorial rail anchors the hero and filters while the main content expands into a responsive results canvas; details slide into an intentional two-column reading layout rather than a generic centered card grid.
- **Signature Elements:** violet “signal” underline on section labels, compact source chips with favicon-like letter marks, and a vertical “fit signal” rail on job cards.
- **Interaction Philosophy:** searching and filtering should feel immediate; cards expose enough context to decide before opening; external application is explicit and honest.
- **Animation:** subtle 160–220ms lift/fade for result updates, soft underline sweep on active navigation, and no looping or attention-grabbing motion.
- **Typography System:** `Space Grotesk` for headlines and labels; `DM Sans` for body copy and data; uppercase micro-labels with generous tracking; compact but readable line-height.
- **Brand Essence:** “A calmer first step into the job market.” Personality: candid, encouraging, sharp.
- **Brand Voice:** headlines are direct and optimistic; CTAs explain the next action. Example lines: “Start with roles that make sense.” / “You’ll apply on the original listing.”
- **Wordmark & Logo:** a lowercase `launchpad` wordmark with a small violet orbital dot replacing the “a” counter; the UI mark is a simple violet square with a cream rising notch.
- **Signature Brand Color:** Launchpad violet `#6755E8`.

## Data/source notes

- Public listings are stored as a refreshable snapshot, not presented as a live mirror.
- Each listing includes a source label and direct source URL. External application always leaves Launchpad.
- LinkedIn and Indeed source pages provide the visible market-search context and individual job links. Palantir’s Lever page provides a fully attributable new-grad detail source. Google Careers is used for the early-career resource strip.
